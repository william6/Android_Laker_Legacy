package edu.gvsu.ll;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


public class MainActivity extends Activity {
	
//	public static MainActivity sInstance;
//	public static Thread threadDBInit;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
//        sInstance = this;
//        
//        threadDBInit = new Thread( new DBInit() );
//        threadDBInit.start();
        
        /* ENTER THE CLASS YOU ARE TESTING RIGHT HERE.
         * IF YOU'RE TESTING THE MAIN ACTIVITY, COMMENT THE FOLLOWING CODE OUT
         **/
        Intent intent = new Intent(this, DirectoryActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
		startActivity(intent);
    }
}

//class DBInit implements Runnable
//{
//	public void run() {
//		//Create database manager
//		File fInternalDir = MainActivity.sInstance.getFilesDir();	//app data directory
//		String strDbName = "Laker_Legacy_DB";
//		DatabaseManager dbManager = new DatabaseManager( MainActivity.sInstance.getApplicationContext(), 
//				strDbName, fInternalDir.getAbsolutePath() + "/database/", 1);   
//		dbManager.createTables();
//		XMLProcessManager xmlManager = new XMLProcessManager(dbManager);
//		xmlManager.addMonuments();
//		xmlManager.addImages();
//		xmlManager.addDonors();
//		xmlManager.addMonDonRelationship();
//	}
//}